package bitsoop.inheritance;

class R1 {
    int j;

}
class R2 extends R1 {

        }
public class Random {
}
