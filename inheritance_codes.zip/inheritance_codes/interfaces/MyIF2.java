package bitsoop.inheritance.interfaces;

public interface MyIF2 {
     String getString() ;

}
