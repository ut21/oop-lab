package bitsoop.inheritance.interfaces;

public interface Callback {

    public void callback(int param);
}