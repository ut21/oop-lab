package bitsoop.inheritance.interfaces;

class MyIFImp implements MyIF {


}