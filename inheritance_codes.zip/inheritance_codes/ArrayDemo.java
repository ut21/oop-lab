package bitsoop.inheritance;

public class ArrayDemo {
    public static void main (String args[] ){
        int a[] = new int[5];
        System.out.print(a);
        //System.out.print(a++);
    }
}
