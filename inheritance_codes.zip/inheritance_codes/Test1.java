package bitsoop.inheritance;

public class Test1 {
    int i;

    Test1(int a) {
        i =a;
    }

    Test1() {

    }
}
