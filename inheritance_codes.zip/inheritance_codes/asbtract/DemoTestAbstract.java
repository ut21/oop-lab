package bitsoop.inheritance.asbtract;

public class DemoTestAbstract extends TestAbstract {

    @Override
    public void generatePrime() {

    }

   // public int doComputation() {

    //}
}
