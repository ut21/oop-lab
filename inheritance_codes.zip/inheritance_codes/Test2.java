package bitsoop.inheritance;

public class Test2 extends Test1 {
    int j;
}
